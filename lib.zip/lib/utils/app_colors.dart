import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  static const Color goldAccent = Color(0xFFD4AF37);

  static const Color black = Color(0xFF000000);

  static const Color brightBlue = Color(0xFF2979FF);

  static const Color white = Color(0xFFFFFFFF);
}
